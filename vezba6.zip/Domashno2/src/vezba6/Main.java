package vezba6;

public class Main {

	public static void main(String[] args) {
		Proizvod obj1 = new Proizvod ();
		
		System.out.println("Cenata na " + obj1.ime + "to so tezhina od " + obj1.tezina + "g iznesuva " + obj1.cena + " denari.");
	}
	
	
	
	
}
