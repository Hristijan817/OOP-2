package vezba6;

public class Proizvod {

	String ime;
	int tezina;
	int cena;
	
	public Proizvod () {
		this.ime = "Chokolado";
		this.tezina = 100;
		this.cena = 55;
	}
	
	
	
}
