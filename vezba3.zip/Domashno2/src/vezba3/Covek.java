package vezba3;

public class Covek {

	public String ime;
	public String prezime;
	public String mBroj;
	
	public Covek () {
		
	}
	
	
	
	
	
}
