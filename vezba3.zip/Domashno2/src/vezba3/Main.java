package vezba3;

public class Main {

	
	public static void main (String[] args) {
		Covek obj1 = new Covek();
		
		obj1.ime = "Hristijan";
		obj1.prezime = "Jankulovski";
		obj1.mBroj = "0902000483005";
		
		System.out.println("Imeto na covekot e: " + obj1.ime + ".");
		System.out.println("Prezimeto na covekot e: " + obj1.prezime + ".");
		System.out.println("Covekot ima maticen broj: " + obj1.mBroj + ".");
	}
	
	
	
	
}
